import re
input = open('connect.properties', 'r')
lines = input.readlines()
pattern = "^([^=]+)=(.+)"
for line in lines:
    stripped = line.strip()
    match = re.match(pattern, stripped)
    if match:
        key = match.group(1)
        value = match.group(2)

        if key != "username":
            variable = "CONNECT"
            for part in re.split("\.", key):
                variable += "_" + part.upper()

            print("{variable}: {value}".format(variable=variable, value=value))




