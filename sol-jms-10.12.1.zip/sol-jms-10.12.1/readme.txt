###############################################################################
# Solace JMS
#                      
# Copyright 2005-2021 Solace Corporation. All rights reserved.
###############################################################################

See the docs directory for more information.
See the lib/dependencies.txt for all libraries needed to build/run applications.

Note that the sol-jms jar includes metadata conforming to the OSGi standards and can be deployed as an OSGi bundle.

If you have any questions or comments regarding the use of the Solace JMS,
contact your Solace support representative or e-mail
support@solace.com.
Thank you!
